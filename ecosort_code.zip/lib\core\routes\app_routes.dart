class AppRoutes {
  static const String auth = '/auth';
  static const String home = '/home';
  static const String history = '/history';
  static const String splash = '/splash';
  static const String otp = '/otp';
}
