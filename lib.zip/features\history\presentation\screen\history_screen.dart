import 'package:flutter/material.dart';
import '../../../../core/services/history_service.dart';
import '../widgets/history_card.dart';
import '../widgets/history_filler_bar.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  String _selectedCategory = 'All';
  List<Map<String, dynamic>> _scans = [];
  bool _isLoading = true;

  final List<String> _categories = [
    'All',
    'Plastic',
    'Paper',
    'Glass',
    'Metal',
    'E-Waste',
  ];

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  void _loadHistory() {
    setState(() => _isLoading = true);
    final data = HistoryService.getAllScans();
    setState(() {
      _scans = data;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    final filteredScans = _selectedCategory == 'All'
        ? _scans
        : _scans.where((scan) {
            final cat = (scan['category'] ?? '').toString().toLowerCase();
            return cat.contains(_selectedCategory.toLowerCase());
          }).toList();

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              child: Row(
                children: [
                  const SizedBox(width: 18),
                  Text(
                    'Scan History',
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.w800,
                      color: colorScheme.primary,
                      letterSpacing: 0.2,
                    ),
                  ),
                ],
              ),
            ),
            HistoryFilterBar(
              categories: _categories,
              selectedCategory: _selectedCategory,
              onSelected: (cat) {
                setState(() => _selectedCategory = cat);
              },
            ),
            const SizedBox(height: 8),
            Expanded(
              child: _isLoading
                  ? Center(
                      child: CircularProgressIndicator(
                        color: colorScheme.primary,
                      ),
                    )
                  : filteredScans.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.history_rounded,
                            size: 64,
                            color: colorScheme.primary.withOpacity(0.3),
                          ),
                          const SizedBox(height: 12),
                          Text(
                            _selectedCategory == 'All'
                                ? 'No scan history yet'
                                : 'No $_selectedCategory waste found',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: colorScheme.primary,
                            ),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 8,
                      ),
                      itemCount: filteredScans.length,
                      itemBuilder: (context, index) {
                        final item = filteredScans[index];
                        final category = item['category'] ?? 'Waste';
                        final summary = item['summary'] ?? 'Sorted & Recycled';
                        final imagePath = item['imagePath'];

                        return HistoryCard(
                          title: '$category Waste',
                          subtitle: summary,
                          imagePath: imagePath,
                          onTap: () {},
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
