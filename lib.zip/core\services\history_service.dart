import 'package:hive_flutter/hive_flutter.dart';

class HistoryService {
  static const String boxName = 'scan_history_box';

  static Future<void> saveScan({
    required String imagePath,
    required String category,
    required double confidence,
    required String summary,
  }) async {
    final box = Hive.box(boxName);
    await box.add({
      'imagePath': imagePath,
      'category': category,
      'confidence': confidence,
      'summary': summary,
      'timestamp': DateTime.now().toIso8601String(),
    });
  }

  static List<Map<String, dynamic>> getAllScans() {
    final box = Hive.box(boxName);
    return box.values
        .map((e) => Map<String, dynamic>.from(e as Map))
        .toList()
        .reversed
        .toList();
  }

  static Future<void> clearHistory() async {
    final box = Hive.box(boxName);
    await box.clear();
  }
}